import java.util.ArrayList;
public class agenda {

 private ArrayList<contato> contatos = new ArrayList<>();

    public void armazenarContato(contato contato) {
        this.contatos.add(contato);
    }

    public void removerContato(contato contatos) {
        this.contatos.remove(contatos);
    }

    public int encontrarContato(String nome) {
        for (int i = 0; i < contatos.size(); i++) {
            if (contatos.get(i).get_nome().equals(nome)) {
                return i;
            }
        }
        return -1; // Retorna -1 se o contato não for encontrado
    }
}
    

