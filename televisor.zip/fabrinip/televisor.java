package POO;

import java.util.ArrayList;
import java.util.List;
public class Televisor{
private int numeroTv;
private int volume;
private Canal canalAtual;
private ArrayList canais;
private boolean ligada;

public Televisor(int numeroTv) {
this.numeroTv = numeroTv;
this.volume = 100;
this.canalAtual = null;
this.canais = new ArrayList<>();
this.ligada = false;

}




public void ligaDesliga (){
this.ligada = !this.ligada;
if (this.ligada) {
System.out.println("A televisão foi ligada!");
} else {
System.out.println("A televisão foi desligada!");
}
}


public void ligar() {
this.ligada = true;
System.out.println("Televisor " + this.numeroTv + " Ligado.");
}

public void desligar() {
this.ligada = false;
System.out.println("Televisor " + this.numeroTv + " Desligado.");
}
}