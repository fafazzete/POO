package POO;

public class Canal {
private String nome;
private int numero;

public Canal(String nome, int numero) {
this.nome = nome;
this.numero = numero;
}
public int getNumero(){
return numero;
}
public String getNome(){
return nome;
}

}
